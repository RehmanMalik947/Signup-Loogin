import { Nav } from 'react-bootstrap';
import './App.css'
import LogIn from './Components/LoginSignup/LogIn';
import Signup from './Components/LoginSignup/Signup';
import Navbar from './Components/LoginSignup/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './Components/LoginSignup/Home';

const router=createBrowserRouter([
  {
    path:'/',
    element:<Signup/>
  },
  {
    path:'/login',
    element:<LogIn/>
  },
  {
    path:'/Navbar',
    element:<Navbar/>
  },
  {
    path:'/home',
    element:<Home/>
  }
]);
function App() {
  return (
    <>
    <RouterProvider router={router}/>
     
    </>
  )
}

export default App
