import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "./Navbar";
import mainImage from "./main.jpg";

const LogIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const handleInput = (event) => {
    const value = event.target.value;
    const name = event.target.name;
    if ("email" === name) {
      setEmail(value);
    }
    if ("password" === name) {
      setPassword(value);
    }
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    const getData = JSON.parse(localStorage.getItem("user"));
    console.log(getData);
  
    const user = getData.find(
      (item) => item.email === email && item.password === password
    );
  
    if (user) {
      window.alert("Login Successfully");
      window.location.href = "/home";
    } else {
      window.alert("Invalid Credentials");
    }
  };
  
  return (
    <>
      <Navbar />
      <div>
        <div className="main-page">
          <form onSubmit={handleSubmit}>
            <div>
              <p>Login</p>
            </div>
            <div className="account">
              <input
                type="text"
                name="email"
                placeholder="enter your email : "
                onChange={handleInput}
              />
              <input
                type="password"
                name="password"
                placeholder="enter your Password : "
                onChange={handleInput}
              />
              <p>
                If you have not account ? <Link to="/">SignUp</Link>
              </p>
            </div>
            <button>Login</button>
          </form>
          <div>
            <img src={mainImage} />
          </div>
        </div>
      </div>
    </>
  );
};

export default LogIn;
