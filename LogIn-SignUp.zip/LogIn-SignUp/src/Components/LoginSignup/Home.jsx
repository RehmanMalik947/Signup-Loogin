import React from 'react'
import Navbar from './Navbar'

const Home = () => {
  return (
    <div>
        <Navbar/>
      <div className='home'>
        <h2>Welcome to Home Page</h2>
        <button>Logout</button>
      </div>
    </div>
  )
}

export default Home
