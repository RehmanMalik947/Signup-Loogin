import React from "react";
import "./LoginSignup.css";
import { Nav } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';

const Navbar = () => {
  return (
    <div>
      <nav>
        <ul>
          <li>
            <a className="heading">Explore!</a>
            <a className="heading">SignUp</a>
            <a className="heading">Login</a>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;
