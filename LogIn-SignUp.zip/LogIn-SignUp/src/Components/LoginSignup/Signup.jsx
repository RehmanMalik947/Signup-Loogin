import React, { useState } from "react";
import "./LoginSignup.css";
import mainImage from "./main.jpg";
import Navbar from "./Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
const Signup = () => {
  const userdetails = {
    name: "",
    email: "",
    password: "",
  };
  const [data, setData] = useState(userdetails);
  const handleSubmit = (event) => {
    event.preventDefault();
    if (data.name === "" || data.email === "" || data.password === "") {
      alert("Please fill all the fields");
      return;
    } else {
      const getData = JSON.parse(localStorage.getItem("user") || "[]");
      let arr = [];
      arr = [...getData];
      arr.push(data);
      localStorage.setItem("user", JSON.stringify(arr));
      window.alert("User Registered Successfully");
      window.location.href = "/login";
    }
  };

  const handleInput = (event) => {
    console.log(event.target.value);
    const name = event.target.name;
    const value = event.target.value;

    setData({ ...data, [name]: value });
  };
  console.log(data);
  return (
    <>
      <Navbar />
      <div>
        <div className="main-page">
          <form onSubmit={handleSubmit}>
            <div>
              <p>SignUp</p>
            </div>
            <div className="account">
              <input
                type="text"
                name="name"
                placeholder="enter your name : "
                onChange={handleInput}
              />
              <input
                type="email"
                name="email"
                placeholder="enter your email : "
                onChange={handleInput}
              />
              <input
                type="password"
                name="password"
                placeholder="enter your Password : "
                onChange={handleInput}
              />
              <p>
                Already have an account ? <Link to="/login">Login</Link>
              </p>
            </div>
            <button>SignUp</button>
          </form>
          <div>
            <img src={mainImage} />
          </div>
        </div>
      </div>
    </>
  );
};
export default Signup;